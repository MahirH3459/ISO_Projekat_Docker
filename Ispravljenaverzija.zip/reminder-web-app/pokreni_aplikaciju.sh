#!/bin/bash
docker-compose up -d
echo "Aplikacija dostupna na http://localhost:3000"